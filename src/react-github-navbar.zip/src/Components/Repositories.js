import React from 'react';

const Repositories = () => {
  return <h1>this is the Repositories tab</h1>
}

export default Repositories;