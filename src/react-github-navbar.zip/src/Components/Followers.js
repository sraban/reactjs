import React from 'react';

const Followers = () => {
  return <h1>this is the Followers tab</h1>
}

export default Followers;