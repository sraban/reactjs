import React from 'react';

const Stars = () => {
  return <h1>this is the Stars tab</h1>
}

export default Stars;