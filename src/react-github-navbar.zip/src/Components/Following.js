import React from 'react';

const Following = () => {
  return <h1>this is the Following tab</h1>
}

export default Following;